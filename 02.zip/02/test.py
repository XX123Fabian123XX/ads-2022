# import sys
# arr = [1,2,3,-10,123,12,-111,1,2,3,4,5,6]



# maxTeilsumme = - sys.maxsize * 2 + 1
# summe = 0
# von = bis = 0
# for i in range(len(arr)):
#     for j in range(len(arr)):



